sap.ui.define(["sap/m/MessageToast"],function(s){"use strict";return{onErrorCodePress:function(e){s.show("Custom handler invoked.")}}});
//# sourceMappingURL=Error.js.map