sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("app.listreportforinternalisation.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);