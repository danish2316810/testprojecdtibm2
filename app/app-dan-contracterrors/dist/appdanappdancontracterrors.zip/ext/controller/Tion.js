sap.ui.define(["sap/m/MessageToast"],function(s){"use strict";return{onPressAction:function(n){s.show("Custom handler invoked.")}}});
//# sourceMappingURL=Tion.js.map