sap.ui.define(["sap/m/MessageToast"],function(s){"use strict";return{onReprocessBtn:function(e){s.show("Custom handler invoked.")}}});
//# sourceMappingURL=CustomFields.js.map